<?php

require_once("connexionbdd.php");

if (isset($_POST['login_connection'])){
    if (empty($_POST['email_connection']) || empty($_POST['password_connection'])){
        echo"<center><h1>Email ou mot de passe ne peuvent etre vide</h1></center>";
    }  
    else{
        $email = $_POST['email_connection'];
        $password = $_POST['password_connection'];
        $query = "SELECT * FROM user WHERE email = :email AND password = :password";
        $result = $pdo->prepare($query);
        
        $result->execute(array( 
            'email' => $_POST['email_connection'],
            'password' => $_POST['password_connection']
        ));
        
        $user_data = $result->rowCount();
        if ($user_data > 0)
        {
            $_SESSION['email_connection'] = $email;
            $_SESSION['password_connection'] = $password;
            echo $email;
            echo $password;
        }
        else{
            echo"<center><h1>Champs erronés</h1></center>";
        }
        //header('Location: http://localhost:8000/php/formulaire.php');*/
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src= "../js/formulaireinscription.js" defer></script>
    <title>Document</title>
</head>
<body>
    <!-- Navbar -->
<header>
    <a href="../index.php" class="logo">
        <i class="bx bx-movie" ></i>Films
    </a>
    <div class="bx bx-menu" id="menu-icon"></div>
    <!-- Menu -->
    <ul class="navbar">
        <li><a href="../index.php" class="home-active">Acceuil</a></li>
        <li><a href="../#movies">Films</a></li>
        <li><a href="apropos.php">A PROPOS</a></li>
    </ul>
    <a href="formulaire.php" class="btn">Connection</a>
</header>
    <section>
        <h2 class="heading">Connexion</h2>
        <div class="connexion">
        <form action="" method="POST">
            <div>
                <p></p>
            </div>
            <label for="email_connection">Email</label>
            <input type="text" id="email_connection" name="email_connection" placeholder="Votre email" autocomplete="off">

            <div>
                <p></p>
            </div>

            <label for="password_connection">Mot de passe</label>
            <input type="password" id="password_connection" name="password_connection" placeholder="Votre mot de passe" autocomplete="off">

            <button type="submit" name="login_connection" value="login_connection">Connexion</button>
        </form>
        </div>
    </section>
    <section>
        <h2 class="heading">Inscription</h2>
        <div class="inscription">
        <form action="inscriptionFormulaire.php" method="POST">
            <div>
                <p></p>
            </div>
            <label for="email_inscription">Email</label>
            <input type="text" id="email_inscription" name="email_inscription" placeholder="Votre email">

            <div>
                <p></p>
            </div>

            <label for="password_inscription">Mot de passe</label>
            <input type="password" id="password_inscription" name="password_inscription" placeholder="Votre mot de passe">

            <div>
                <p></p>
            </div>

            <label for="repeat_password_inscription">Mot de passe à nouveau</label>
            <input type="password" id="repeat_password_inscription" name="repeat_password_inscription" placeholder="à nouveau le mot de passe">

            <button type="submit" >Envoyer</button>
        </form>
        </div>
    </section>
    <?php require_once("footer.php"); ?>
</body>
</html>