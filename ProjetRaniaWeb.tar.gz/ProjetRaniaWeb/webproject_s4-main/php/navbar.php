<!-- Navbar -->
<header>
    <a href="../index.php" class="logo">
        <i class="bx bx-movie" ></i>Films
    </a>
    <div class="bx bx-menu" id="menu-icon"></div>
    <!-- Menu -->
    <ul class="navbar">
        <li><a href="../index.php" class="home-active">Acceuil</a></li>
        <li><a href="#movies">Films</a></li>
        <li><a href="php/apropos.php">A PROPOS</a></li>
    </ul>
    <a href="php/formulaire.php" class="btn">Connection</a>
</header>
