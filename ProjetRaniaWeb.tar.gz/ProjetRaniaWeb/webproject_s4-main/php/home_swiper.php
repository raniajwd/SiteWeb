<!-- Home swiper -->
<section class="home swiper" id="home">
    <div class="swiper-wrapper">
         <!-- Box 1 -->
        <div class="swiper-slide conatiner">
            <img src="img/home1.jpg" alt="">
            <div class="home-text">
                <span>Marvel Universe</span>
                <h1>Venom: Let There <br> Be Carnage</h1>
                <a href="#" class="btn">Regader maintenant</a>
                <a href="#" class="play">
                    <i class="bx bx-play" ></i>
                </a>
            </div>
        </div>
        <!-- Box 2 -->
        <div class="swiper-slide conatiner">
            <img src="img/home2.jpg" alt="">
            <div class="home-text">
                <span>Marvel Universe</span>
                <h1>Avengers: <br>Infity War</h1>
                <a href="#" class="btn">Regarder maintenant</a>
                <a href="#" class="play">
                    <i class="bx bx-play" ></i>
                </a>
            </div>
        </div>
        <!-- Box 3 -->
        <div class="swiper-slide conatiner">
            <img src="img/home3.jpg" alt="">
            <div class="home-text">
                <span>Marvel Universe</span>
                <h1>Spider-Man: <br>Far Frome Home</h1>
                <a href="#" class="btn">Regader maintenant</a>
                <a href="#" class="play">
                    <i class="bx bx-play" ></i>
                </a>
            </div>
        </div>
    </div>
    <div class="swiper-pagination"></div>
</section>