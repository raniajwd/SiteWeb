<!-- Arrive bientot -->
<section class="coming" id="coming">
    <h2 class="heading">Arrive Prochainement</h2>
    <!--Conteneur des films qui arrive bientot -->
    <div class="coming-container swiper">
        <div class="swiper-wrapper">
            <!-- Box 1 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming1.jpg" alt="">
                </div>
                <h3>Johnny English Strikes Again</h3>
                <span>120 min | Action </span>
            </div>
            <!-- Box 2 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming2.jpg" alt="">
                </div>
                <h3>The old Guard</h3>
                <span>120 min | Adventure </span>
            </div>
            <!-- Box 3 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming3.jpg" alt="">
                </div>
                <h3>Rampage</h3>
                <span>120 min | Thriller</span>
            </div>
            <!-- Box 4 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming4.jpg" alt="">
                </div>
                <h3>The Commando</h3>
                <span>120 min | Adventure</span>
            </div>
            <!-- Box 5 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming5.jpg" alt="">
                </div>
                <h3>Black Light</h3>
                <span>120 min | Action</span>
            </div>
            <!-- Box 6 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming6.jpg" alt="">
                </div>
                <h3>Doctor Strange</h3>
                <span>120 min | Thriller</span>
            </div>
            <!-- Box 7 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming7.jpg" alt="">
                </div>
                <h3>Captain Marvel</h3>
                <span>120 min | Adventure</span>
            </div>
            <!-- Box 8 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming8.jpg" alt="">
                </div>
                <h3>Black Window</h3>
                <span>120 min | Thriller</span>
            </div>
            <!-- Box 9 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/coming9.jpg" alt="">
                </div>
                <h3>Ant-Man</h3>
                <span>120 min | Action</span>
            </div>
            <!-- Box 10 -->
            <div class="swiper-slide box">
                <div class="box-img">
                    <img src="img/m10.jpg" alt="">
                </div>
                <h3>UnderWorld | Blood Wars</h3>
                <span>120 min | Action</span>
            </div>
        </div>
    </div>
</section>