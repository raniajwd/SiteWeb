<?php

//Recuperation du dossier parent
$path = dirname(__FILE__);

//Connection à la base de données
require_once("connexionbdd.php");

try{
//Creation de la table user et des differentes colonnes
$pdo->query("
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)");}catch (PDOException $e){
    echo "erreur creation des tables";
}

//verification de la faille XSS
$email = htmlspecialchars($_POST['email_inscription']);
$password = htmlspecialchars($_POST['password_inscription']);
$reapeat_password = htmlspecialchars($_POST['repeat_password_inscription']);

//email -> format email et longueur < 255
//password -> longueur = + grand que 8 caractères et longueur < 255


if (preg_match('#[a-z0-9-_.]+@[a-z0-9-_.]+\.[a-z]{2,}#', $email) &&
    strlen($email) <= 255 &&
    strlen($password) >= 8 &&
    $password === $reapeat_password
) {
    echo "hey";
    try {
        $statement = $pdo->prepare("
            INSERT INTO user ('email', 'password')
            VALUES (:email, :password)
        "); 
        // Faille injection SQL
        $statement->bindValue(':email', $email);
        $statement->bindValue(':password', $password);
        $statement->execute();
    } catch (PDOException $exception) {
        // traitement de l'erreur par rapport à UNIQUE => email
    }
}

header('Location: http://localhost:8000/php/formulaire.php');

?>

