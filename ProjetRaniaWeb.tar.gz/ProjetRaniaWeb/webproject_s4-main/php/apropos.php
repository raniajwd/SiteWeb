<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="../css/style.css">
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- Navbar -->
<header>
    <a href="../index.php" class="logo">
        <i class="bx bx-movie" ></i>Films
    </a>
    <div class="bx bx-menu" id="menu-icon"></div>
    <!-- Menu -->
    <ul class="navbar">
        <li><a href="../index.php" class="home-active">Acceuil</a></li>
        <li><a href="../#movies">Films</a></li>
        <li><a href="apropos.php">A PROPOS</a></li>
    </ul>
    <a href="formulaire.php" class="btn">Connection</a>
</header>

    <section class="apropos">
        <h2 class="heading">A propos</h2>
        <div>
            <p>
                Raptim igitur properantes ut motus sui rumores celeritate nimia praevenirent,<br>
                vigore corporum ac levitate confisi per flexuosas semitas ad summitates collium tardius evadebant.<br> 
                et cum superatis difficultatibus arduis ad supercilia venissent fluvii Melanis alti et verticosi,<br>
                qui pro muro tuetur accolas circumfusus, augente nocte adulta terrorem quievere paulisper lucem opperientes.<br> 
                arbitrabantur enim nullo inpediente transgressi inopino adcursu adposita quaeque vastare, <br>
                sed in cassum labores pertulere gravissimos.
            </p>
        </div>
    </section>
    <?php require_once("footer.php"); ?>
</body>
</html>