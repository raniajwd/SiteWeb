<!-- Movies -->
<section class="movies" id="movies">
    <h2 class="heading">Ouverture Cette Semaine</h2>
    <!-- Conteneur films -->
    <div class="movies-container">
        <!-- Box 1 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m1.jpg" alt="">
            </div>
            <h3>Venom</h3>
            <span>120 min | Action </span>
        </div>
        <!-- Box 2 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m2.jpg" alt="">
            </div>
            <h3>Dunkirk</h3>
            <span>120 min | Adventure </span>
        </div>
        <!-- Box 3 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m3.jpg" alt="">
            </div>
            <h3>Batman Vs Superman</h3>
            <span>120 min | Thriller</span>
        </div>
        <!-- Box 4 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m4.jpg" alt="">
            </div>
            <h3>John Wick 2</h3>
            <span>120 min | Adventure</span>
        </div>
        <!-- Box 5 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m5.jpg" alt="">
            </div>
            <h3>Aquaman</h3>
            <span>120 min | Action</span>
        </div>
        <!-- Box 6 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m6.jpg" alt="">
            </div>
            <h3>Black Panther</h3>
            <span>120 min | Thriller</span>
        </div>
        <!-- Box 7 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m7.jpg" alt="">
            </div>
            <h3>Thor</h3>
            <span>120 min | Adventure</span>
        </div>
        <!-- Box 8 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m8.jpg" alt="">
            </div>
            <h3>Bumblebee</h3>
            <span>120 min | Thriller</span>
        </div>
        <!-- Box 9 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m9.jpg" alt="">
            </div>
            <h3>Mortal Engines</h3>
            <span>120 min | Action</span>
        </div>
        <!-- Box 10 -->
        <div class="box">
            <div class="box-img">
                <img src="img/m10.jpg" alt="">
            </div>
            <h3>UnderWorld | Blood Wars</h3>
            <span>120 min | Action</span>
        </div>
    </div>
</section>