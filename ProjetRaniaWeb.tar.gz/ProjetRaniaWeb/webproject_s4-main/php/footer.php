<!-- Footer -->
<footer>
    <section class="footer">
        <a href="#" class="logo">
            <i class="bx bx-movie" ></i>Films
        </a>
        <div class="social">
            <a href="#">
                <i class='bx bxl-facebook'></i>
                <i class='bx bxl-instagram'></i>
                <i class='bx bxl-twitter'></i>
                <i class='bx bxl-tiktok'></i>
            </a>
        </div>
    </section>
</footer>