<?php

$path = dirname(__FILE__);

try{
$pdo = new PDO("sqlite:$path/../bdd/database.sqlite");
}catch(PDOException $e){
    echo $e->getMessage();
}
?>





































