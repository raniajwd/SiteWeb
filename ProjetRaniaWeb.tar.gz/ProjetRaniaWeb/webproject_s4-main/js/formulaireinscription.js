const form = document.querySelector('section:nth-of-type(2) form')

form.addEventListener('submit', function(event){
    event.preventDefault()
    let error_email = false
    let error_password = false
    let error_repeat_password = false
    const email = document.getElementById('email_inscription')
    const password = document.getElementById('password_inscription')
    const repeat_password = document.getElementById('repeat_password_inscription')


    if (email.value === null ||
        !/[a-z0-9-_.]+@[a-z0-9-_.]+\.[a-z]{2,}/.test(email.value)) {
        error_email = true
        email.classList.add('error')
        const paragraph_1 = document.querySelector('section:nth-of-type(2) form div:nth-of-type(1) p')
        paragraph_1.classList.add('error')
        paragraph_1.innerText = 'Votre email n\'a pas le bon format'

    }

    if (password.value.length < 8){
        error_password = true
        password.classList.add('error')
        const paragraph_2 = document.querySelector('section:nth-of-type(2) form div:nth-of-type(2) p')
        paragraph_2.classList.add('error')
        paragraph_2.innerText = 'Votre mot de passe comporte moins de 8 caractères'

    }
    
    if (repeat_password.value === null || repeat_password.value !== password.value)
    {
      error_repeat_password = true
      repeat_password.classList.add('error')
      const paragraph_3 = document.querySelector('section:nth-of-type(2) form div:nth-of-type(3) p')
      paragraph_3.classList.add('error')
      paragraph_3.innerText = 'les mots de passe ne concorde pas'
    }


    if (error_email === false && error_password === false && error_repeat_password === false){
        this.submit()
    }
})