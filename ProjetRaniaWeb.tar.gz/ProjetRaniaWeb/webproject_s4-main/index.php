<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MonSiteWeb Responsive</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <!-- Swiper css -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"
    />
</head>
<body>
</body>
    <?php require_once("php/navbar.php"); ?>
    <?php require_once("php/home_swiper.php"); ?>
    <?php require_once("php/film.php"); ?>
    <?php require_once("php/coming.php"); ?>
    <?php require_once("php/footer.php"); ?>
    <!-- Swiper JS --> 
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- main.js-->
    <script src="js/main.js"></script>
</html>